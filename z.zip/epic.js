var q1="whats 1+1"
console.log(q1)
var answer_1=eval(1+1)
var q2="2x=10 find x"
var x=5
if (x>5) {x=5}
if (x<5) {
    x=5
}
eval(answer_1)
eval(answer_2)
true
var answer_2=eval(2*x,(10))
console.log(q2)
console.log("you epicly done:D!")