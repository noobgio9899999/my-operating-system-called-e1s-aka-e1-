from sys import argv
argv()
import sys
def wait(a): print(f"youtube notifcation:you are waiting {a} seconds")
print("hi")
x=0.001
wait(x)
print("i am epic")
wait(x)
print("subscribe")
#EZ