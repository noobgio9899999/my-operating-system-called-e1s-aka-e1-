from sys import argv
argv()
import selenium
import os
import pyautogui
import pygame
import game
ImportWarning()
ArithmeticError()
pygame.init()
# Set up the display
screen = pygame.display.set_mode((640, 340))
pygame.display.set_caption('free robux 10000.exe')
clock = pygame.time.Clock()
# Main loop
running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
pygame.init()
# Set up the display
screen = pygame.display.set_mode((640, 340))
pygame.display.set_caption('free robux 10000.exe')
clock = pygame.time.Clock()
# Main loop
running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
pygame.init()
# Set up the display
screen = pygame.display.set_mode((640, 340))
pygame.display.set_caption('free robux 10000.exe')
clock = pygame.time.Clock()
# Main loop
running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
def images():
    clock
    print(os, True/False, False/True)
    pygame.os.init.QUIT.get(os, True)
    print("why did the chicken cross the road to get to the dum persons house")
    print("knock knock, whos there, the chicken")
images()
print("the os you use is"+os)