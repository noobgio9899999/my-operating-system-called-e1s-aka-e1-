import sys
local q1="whats 1+1"
print(input(q1))
local q2="2x=10 find x"
print(input(q2))
local l=print("u done")