from sys import argv
argv()
ArithmeticError(print("u have entered a math thing that we cant solve cuz we can only do arithmetic", False))
import os
del "u"
def epic():
    print("hecker")
    AttributeError()
    print(os, True/False)
if "u" in os==False:
    epic()
while True:
    epic()