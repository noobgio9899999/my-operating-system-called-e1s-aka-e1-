from sys import argv
argv()
import sys
epic="hello there"
x=" "
key="w"
say1="how many subscribers does mrbeast have"
print(input(say1))
if key=="backspace":print(input(x))
say=10000100100010101000100101000000010010101000010101001010011110000110100101010101010101
print("397M")
uygtr=7
a=[0,1,2,3,4,5,6,7,8,9]
def r():print(a[x])
b=[0,1]
def binary(i): (a) in print(r(b))
binary(say1)