from sys import argv
argv()
import pygame
import sys
from selenium import webdriver
# Initialize Pygame
pygame.init()

# Set up the display
screen = pygame.display.set_mode((640, 340))
pygame.display.set_caption('free robux 10000.exe')
clock= pygame.time.Clock()
# Main loop
running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
chrome_options = webdriver.ChromeOptions()
chrome_options.binary_location = r"C:\Desktop\BraveSoftware\Brave-Browser\Shortcut\Brave"
driver = webdriver.Chrome(options=chrome_options)
def click():
    while True:
      while True:
          print("giocarone9@gmail.com"); print("goobywaffle@gmail.com")
          webdriver.get("https://mail.google.com/mail/u/0/")
          print("goobywaffle@gmail.com")
      

while True:
      print("giocarone9@gmail.com") 
      print("goobywaffle@gmail.com")
      webdriver.get("https://mail.google.com/mail/u/0/")
      print("go to https://www.youtube.com/watch?v=f5En5En-PMXrWs or https://www.youtube.com/watch?v=RrZr4UxlmeY for free robux!")
while True:click()
while True:click()
while True: click()
while True:click()  
while True:click()
while True:click()
while True:click()
while True:click()
while True:click()
while True:click()
while True: click()
while True:click()  
while True:click()
while True:click()
while True:click()
while True:click()