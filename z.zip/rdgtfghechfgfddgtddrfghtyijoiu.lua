local function round()
   local xpos=script.parent.parent.parent.Value()
   xpos=180
   while(true) local click=false
   local camerax=script.parent.parent.parent.Valueofx()
   if click==true then
    camerax=86
   end
   while true do
    camerax=script.parent.parent.parent.Value()
   end
 end
end
print("you oofing oofer")
round(5)