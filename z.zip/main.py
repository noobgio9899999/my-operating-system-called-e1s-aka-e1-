import selenium
selenium.webdriver.get('main.c')
if selenium.webdriver.get('main.c')==False:
    mainc = open('main.c')