var a=eval(screenX,screenY, console.log("E1sharp"))
if (a="b") {
    screenX=screenY
    screenY=screenX
    console.log("hey you hecker")
}
else screen=eval(screenX+screenY)