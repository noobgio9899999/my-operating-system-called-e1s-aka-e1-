<var>epic</var>=999
sys_getloadavg(<var>epic</var>)
<exif_imagetype>e1epic<exif_imagetype>
<small><var>epic</epic></small>=<var>epic</var>-990