from sys import argv
argv()
print("type call stack to unlock json")
a=input("")
if a=="call stack":
    print(f"{a}.json")
    print(input(""))