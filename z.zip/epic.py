from sys import argv
argv()
a="z"
import pygame
import sys
pygame.init()
screen=pygame.display.set_mode((657, 560))
pygame.display.set_caption('Gt48 program')
clock=pygame.time.Clock()
running=True
while running:
      for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running=False
commands=["errsaywordepic.Cmdisplay","err.hdCm.dis","Y","N"]
def typing(errsaywordepic):
 print("errsaywordepic")
 import os
 a=(input("run command(Y/N)"))
 while True: print(input(""))
if typing("errsaywordepic"): print("epic")
if a=="Y":
  print("ok") 
if a=="N":
  event.type=pygame.QUIT