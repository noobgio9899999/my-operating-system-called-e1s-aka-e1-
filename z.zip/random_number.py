from sys import argv
argv()
a=input("")
import random
if a=="pick a random number":
    b=[1,2,3,4,5,6,7,8,9,10]
    def randomnumber():
        print(random.randit(b[random(b)]))
    randomnumber()