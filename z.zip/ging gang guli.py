from sys import argv
argv()
import sys
sound="ginggangguliguliguliwatchadinggonggooooolinggonggul"
def sdudeyudfy():
 print(sound)
 return sound; #this makes the ging gang guli sound epicly
def text(a): print("your phone is ringing")
on_mobilecontrol=False
a=print(input("would you like to turn on mobile controls yes or no"))
print(input("would you like to turn on mobile controls yes or no"))
if a==print(input("would you like to turn on mobile controls")):print("if you did not say yes or no then the fbi is hunting you")
def fbihunting(l):print("fbi open up")
def wait(a): print(f"you waiting {a} seconds")
x=0.95
wait(x)
fbihunting("hey")
print("ayo")
sdudeyudfy()
gdjhfgfggfyftyfdrtdfdgyuhgggfcvgfdfgfddfgfdghfhjgftyfdrtdfffgfggcfgxrrrrrrrydhygghjghbghgghjhhdghhgfhgffgcxdggdfsdrdddgftggfgfhghgffgffgfdfgvbfghfdgdfcfgcvgfdcfgtdfgdfftrtgfgfghfghhgfhfhfdghfhfhfhjhgchregfyedgfehdgchedghrfhgrugtrughdfvbddvdbcvdghxvnvbdhgjfghjrhfydudghcgehgfdhsgxgdgfghdsddrfbghgjhdhbgrfxnhydgtbhnchegaudfhdyuszuydtydusjhgdtye6tdgfdeghtfghdegfwhtyfjhfryefedfhgfghgtfghdgcgdbgtgdbfryhfbgebdvfetgdvcbdfgvcbdgergfcbdtrfcgvbvgfgcvvgv=1234567890
wait(1)
privated=False
sound="ginggangguliguliguliwatchadinggonggooooolinggonggul"
def sdudeyudfy():
 print(sound)
 return sound
if privated==True:
  print("hey you are calling well no one is looking")
  from selenium import webdriver
def realcall():
    def callingepic(z): print(f"{z} is calling you")
    x="ya boi jerickamo"
    callingepic(x)
    def nocall():print(input("(( do not call them"))
    def call():print(input("() call them"))
    call()
    print("or")
    nocall()
    if call()=="yes": call()==True 
    if call()=="no": call()==False
    sdudeyudfy()
    if call()==True:print("its probably your boi jerickamo")
realcall()
def private():
 print("make sure you have mobile controls")
 import os
 privated=True
 def imporant(): 
  realcall()
  print("ayy dawg")
 imporant(); print("wassup")
 return imporant(), "wassup"
 del realcall()
 b="tutututututuuttugututu"
 return b
while True:
 private()