from sys import argv
argv()
a=input("")
if a=="whats 1+1":
    print(2)