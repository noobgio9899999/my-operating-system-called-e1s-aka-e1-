from sys import argv
argv()
crash=False
if crash==True:
 import pygame
 pygame.init()
 screen = pygame.display.set_mode((640, 480))
 pygame.display.set_caption("RIFFF WEBPVP8X  ù 5 ALPH‘  Çÿÿù6ú$)fÛV;ómd¶w¾á4£:Õq¶í­˜«™éì-¹úÚ¥ùüñ}ÿ¾¿ü~û6GÄ´¥fÛ×#¿ú!2úßU»’SRÎ:Îë.—ËÍÌœír¹n9Î))‡w¯Y9eü¨>ow©Hþ~™Â·\\}ÌOæÝ}s†ÖòßÊGfó^¼²™ŸÖá*+0o P§ 0S§,V¢wDÉ—À°‘‰*]gEuÖzÇ...")
 running = True
 while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False