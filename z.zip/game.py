from sys import argv
argv()
import sys
game1_player="[(0)]"
def letter():print(input(letter()))
key="w"
print(game1_player)
if key=="i":print(game1_player)
map="[_______________________________________________________________________________________/\__[]]"
a=1
key(a)