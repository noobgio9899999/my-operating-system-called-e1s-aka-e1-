from sys import argv
argv()
a=input("")
if a=="how many digits of pi are there":
 print("infinite")
#end