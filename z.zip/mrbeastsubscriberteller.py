from sys import argv
argv()
a=input("")
if a=="how many subs does mrbeast have":
    print("around 403M")