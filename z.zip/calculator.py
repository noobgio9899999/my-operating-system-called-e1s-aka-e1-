from sys import argv
argv()
import sys
a = int(input("addition 1st number: "))
b = int(input("additon 2nd number: "))
print("add:", a+b)
print("do you want to restart")
# errrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrr