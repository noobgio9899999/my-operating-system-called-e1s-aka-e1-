from sys import argv
argv()
import sys
onfunc="-----open-----"
offfunc="       "
print(offfunc)
print(onfunc)
print(input("would you like to turn on your pc"))
print(input("would you to like to turn off your pc"))
def key(a): print("a")
def key(b): print("b")
from selenium import webdriver
webdriver.get("e1.html")