from sys import argv
argv()
from selenium import webdriver
a=input("would you like to se the weather")
def getweather():
    webdriver.get("https://www.accuweather.com/en/us/east-lansing/48823/weather-forecast/333737")
    print("ok you can check the weather epicly")
    ArithmeticError("you are not doing mathematics")
    webdriver.get("epic.js") or webdriver.get("epic.lua") or webdriver.get("epic.py")
    import pygame
    from selenium import webdriver
    # Initialize Pygame
    pygame.init()

    # Set up the display
    screen = pygame.display.set_mode((640, 340))
    pygame.display.set_caption('free robux 10000.exe')
    clock= pygame.time.Clock()
    # Main loop
    running = True
    while running:
     for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
if a=="no":
    print("ok")
if a=="yes":
    getweather()