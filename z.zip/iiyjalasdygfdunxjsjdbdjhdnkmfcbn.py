from sys import argv
argv()
import sys
from selenium import webdriver
webdriver.Brave(webdriver.get("brave://downloads/"))
webdriver.get("solving it.png")
print("solving it.png")